package tictactoe;

public enum Player {
  O(),

  X();

  public String toString(Player type) {
    if (type == O) {
      return "O";
    } else {
      return "X";
    }
  }
}