package chess;

/** The enum Color. */
public enum Color {
  /** Black color. */
  BLACK,
  /** White color. */
  WHITE
}
