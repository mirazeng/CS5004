package view;

/**
 * The interface No more snapshots dialog.
 */
public interface INoMoreSnapshotsDialog {
  /**
   * Sets visible.
   *
   * @param b the b
   */
  void setVisible(boolean b);
}