package hw2;

/**
 * Wenqing Zeng - HW_2
 * This enumeration represents types of rooms.
 */
public enum RoomType {
    SINGLE, DOUBLE, FAMILY;
}