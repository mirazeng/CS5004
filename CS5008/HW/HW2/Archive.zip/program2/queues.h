#ifndef PROGRAM2_QUEUES_H
#define PROGRAM2_QUEUES_H

void combine(int *queue_1,int size_1,int *queue_2,int size_2,int *finalqueue);

#endif //PROGRAM2_QUEUES_H
