#ifndef PROGRAM1_DEFRAG_H
#define PROGRAM1_DEFRAG_H

void defragment(int *array, int size);

#endif //PROGRAM1_DEFRAG_H
