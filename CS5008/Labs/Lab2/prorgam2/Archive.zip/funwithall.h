#ifndef PRORGAM2_FUNWITHALL_H
#define PRORGAM2_FUNWITHALL_H
char shift(char *str, int x);
char next(char ch);
char change_case(char ch);
#endif //PRORGAM2_FUNWITHALL_H
