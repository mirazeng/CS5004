#include <string.h>
#include <stdio.h>

// This function shifts the letters in a string by x positions
// also known as Caesar cipher
char shift(char *str, int x)
{
    // start a loop to iterate through the string
    // with iterator i
    for (int i = 0; i < strlen(str); i++) {
        // initialize code to store letter's ASCII value
        int code = (int) str[i];

        // check if the character is a letter and in upper case
        if (code >= 65 && code < 90) {
            // find the difference between the letter's ASCII value and base upper case ASCII value
            // plus the shift value
            // adding 26 to the result to allow for negative shift values
            // module 26 to wrap around the alphabet with 26 letters
            // keep it in range 0 to 25
            // make sure alphabet in ASCII value to the result by adding 65
            code = ((code - 65 + x + 26) % 26) + 65;
        } else {
            // check if the character is a letter and in lower case
            if (code >= 90 && code <= 122) {
                code = ((code - 97 + x + 26) % 26) + 97;
            }
        }
        // convert the ASCII value back to a character
        str[i] = (char) code;
        printf("%c", str[i]);
    }
    return *str;
}