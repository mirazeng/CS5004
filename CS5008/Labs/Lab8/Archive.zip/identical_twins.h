#ifndef LAB8_IDENTICAL_TWINS_H
#define LAB8_IDENTICAL_TWINS_H

#include <stdbool.h>

#endif //LAB8_IDENTICAL_TWINS_H
